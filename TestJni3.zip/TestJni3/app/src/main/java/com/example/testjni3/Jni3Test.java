package com.example.testjni3;

public class Jni3Test {
    static {
        System.loadLibrary("Jni3Test");
    }
    public static native String getJniTestString();
}
