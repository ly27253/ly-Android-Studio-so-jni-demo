//
// Created by ly on 2021/8/15.
//

#include "jni.h"
#include "com_example_testjni3_Jni3Test.h"
JNIEXPORT jstring JNICALL Java_com_example_testjni3_Jni3Test_getJniTestString
   (JNIEnv *env, jclass jz)
  {
     return (*env)->NewStringUTF(env,"ly miss family and study Android jni");
   }
