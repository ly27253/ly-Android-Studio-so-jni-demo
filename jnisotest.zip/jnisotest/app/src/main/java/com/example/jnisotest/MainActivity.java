package com.example.jnisotest;

import androidx.appcompat.app.AppCompatActivity;
import com.example.testjni.JNITest;
import android.util.Log;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String str1 = JNITest.getJniTestString();
        //TextView tv =
        System.out.println(1);
        //System.out.print(str1);
        Log.v("shizhe",str1);
    }
}