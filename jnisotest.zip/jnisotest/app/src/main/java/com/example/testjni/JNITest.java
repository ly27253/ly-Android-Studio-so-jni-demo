package com.example.testjni;

public class JNITest {
        static {
            System.loadLibrary("JNITest");
        }
        public static native String getJniTestString();
}
